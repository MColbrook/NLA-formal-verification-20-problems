module

import Solution

#print axioms NLA.NM04.Paper.paper_rowland_wu_identity
