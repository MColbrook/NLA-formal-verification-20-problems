module

import Solution

#print axioms NLA.MI21.Paper.paper_counterexample
