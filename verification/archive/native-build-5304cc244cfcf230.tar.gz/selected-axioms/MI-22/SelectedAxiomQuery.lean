module

import Solution

#print axioms NLA.MI22.Paper.paper_counterexample
#print axioms NLA.MI22.Paper.paper_conjecture_false
