module

import Solution

#print axioms NLA.IE21.Paper.paper_random_rows
