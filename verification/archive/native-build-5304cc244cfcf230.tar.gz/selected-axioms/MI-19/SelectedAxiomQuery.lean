module

import Solution

#print axioms NLA.MI19.Paper.paper_counterexample
