module

import Solution

#print axioms NLA.RA02.Paper.paper_sup_worst_case_constants
