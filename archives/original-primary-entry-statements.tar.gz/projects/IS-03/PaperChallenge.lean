import NLA.IS03.Definitions

/- Independent statement of main.tex, Theorem thm:is03, including every zero padding.
The deliberate statement holes in this file are not proof dependencies. -/
noncomputable section
namespace NLA.IS03

theorem paper_padded_seventh_trace {n : ℕ} (B : RealMatrix n) (r : ℕ)
    (hB : B.charpoly = Polynomial.X ^ r * derivativePolynomial) :
    Matrix.trace (B ^ 7) = -8593 / 823543 := by
  sorry

theorem paper_counterexample :
    EntrywiseNonnegative witnessMatrix ∧
    ∀ (r : ℕ) (B : RealMatrix (6 + r)), EntrywiseNonnegative B →
      B.charpoly ≠ Polynomial.X ^ r * normalizedDerivative 7 witnessMatrix.charpoly := by
  sorry

end NLA.IS03
