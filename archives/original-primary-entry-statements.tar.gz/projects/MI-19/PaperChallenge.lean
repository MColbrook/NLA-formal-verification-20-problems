import NLA.MI19.PaperDefinitions

set_option autoImplicit false
open scoped ComplexOrder
noncomputable section
namespace NLA.MI19.Paper

theorem paper_counterexample :
    realWitness.PosSemidef ∧ realWitness.rank = 2 ∧
    witness = realWitness.map (fun x : ℝ => (x : ℂ)) ∧
    0 ≤ witnessQ ∧ witnessQ ≤ 1 ∧
    witnessSubset.Nonempty ∧ witnessSubset ≠ Finset.univ ∧
    qPermanent witnessQ witness - restrictedQPermanent witnessQ witness witnessSubset =
      (-3235575 / 16384 : ℂ) ∧
    qPermanent witnessQ witness < restrictedQPermanent witnessQ witness witnessSubset := by
  sorry

end NLA.MI19.Paper
