import NLA.PF02.UniformPositiveOrientation.RationalDefinitions
import NLA.PF02.UniformPositiveOrientation.RegularDefinitions
import NLA.PF02.UniformPositiveOrientation.CovarianceDefinitions
import Mathlib.Topology.Instances.Matrix
import Mathlib.Topology.Connected.TotallyDisconnected
set_option autoImplicit false
noncomputable section
namespace Reference.PF02UniformPositiveOrientation
open Matrix Reference.PF02GlobalOrientation Reference.PF02BlockConstruction Reference.PF02Normalization
open Reference.PF02JointCompactness Reference.PF02Support Set Filter
open scoped BigOperators Topology MatrixOrder

theorem orthogonal_set_isClosed (k : ℕ) : IsClosed (orthogonalSet k) := by sorry

theorem orthogonal_entry_bound {k : ℕ} (O : Matrix (Fin k) (Fin k) ℝ)
    (hO : O ∈ orthogonalSet k) (a b : Fin k) : |O a b| ≤ 1 := by sorry

theorem orthogonal_set_isCompact (k : ℕ) : IsCompact (orthogonalSet k) := by sorry

theorem row_sum_congruence {p k : ℕ} (A C : Fin p → Mat (Fin k)) (S : Mat (Fin k))
    (hRows : ∀ i, C i = S.transpose * A i * S) : rowSum C = S.transpose * rowSum A * S := by sorry

theorem normalizing_congruence_orthogonal {p k : ℕ} (A C : Fin p → Mat (Fin k))
    (hA : ∀ i, (A i).PosSemidef) (hC : ∀ i, (C i).PosSemidef)
    (hPD : (rowSum C).PosDef) (S : Mat (Fin k))
    (hRows : ∀ i, C i = S.transpose * A i * S) :
    normalizingCongruence A C S ∈ orthogonalSet k := by sorry

theorem normalized_row_congruence {p k : ℕ} (A C : Fin p → Mat (Fin k))
    (hPD : (rowSum A).PosDef) (S : Mat (Fin k))
    (hRows : ∀ i, C i = S.transpose * A i * S) (i : Fin p) :
    normalizedRow C i = (normalizingCongruence A C S).transpose * normalizedRow A i * normalizingCongruence A C S := by sorry

theorem shifted_psd {p k : ℕ} (A : Fin p → Matrix (Fin k) (Fin k) ℝ)
    (hA : ∀ i, (A i).PosSemidef) (η : ℝ) (hη : 0 ≤ η) (i : Fin p) :
    (shiftedFactors A η i).PosSemidef := by sorry

theorem shifted_posDef {p k : ℕ} (A : Fin p → Matrix (Fin k) (Fin k) ℝ)
    (hA : ∀ i, (A i).PosSemidef) (η : ℝ) (hη : 0 < η) (i : Fin p) :
    (shiftedFactors A η i).PosDef := by sorry

theorem actual_shifted_factorization (r : ℕ) (η : ℝ) (hη : 0 ≤ η) :
    NLA.PF02.IsFactorization (perturbedBlockGram r η)
      (shiftedFactors (enumeratedFactor r) η,shiftedFactors (enumeratedFactor r) η) := by sorry

theorem finite_reflected_entry_covariance (r : ℕ) (p : BlockIndex r) :
    finiteReflectedBlockFactor r p = entryReflection
      (finSumFinEquiv (Sum.inl (0 : Fin 3)) : Fin (3+r))
      (finSumFinEquiv (Sum.inl (1 : Fin 3)) : Fin (3+r)) (finiteBlockFactor r p) := by sorry

theorem enumerated_reflected_entry_covariance (r : ℕ) (i : Fin (Fintype.card (BlockIndex r))) :
    enumeratedReflectedFactor r i = entryReflection
      (finSumFinEquiv (Sum.inl (0 : Fin 3)) : Fin (3+r))
      (finSumFinEquiv (Sum.inl (1 : Fin 3)) : Fin (3+r)) (enumeratedFactor r i) := by sorry

theorem actual_shifted_reflected_factorization (r : ℕ) (η : ℝ) (hη : 0 ≤ η) :
    NLA.PF02.IsFactorization (perturbedBlockGram r η)
      (shiftedFactors (enumeratedReflectedFactor r) η,shiftedFactors (enumeratedReflectedFactor r) η) := by sorry

theorem compact_parameter_positive {X Y : Type*} [TopologicalSpace X] [TopologicalSpace Y]
    (K : Set (ℝ × X)) (L : Set Y) (hK : IsCompact K) (hL : IsCompact L)
    (g : X × Y → ℝ) (hg : Continuous g)
    (hzero : ∀ x : X, (0,x) ∈ K → ∀ y : Y, y ∈ L → 0 < g (x,y)) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ t : ℝ, |t| < ε →
      ∀ x : X, (t,x) ∈ K → ∀ y : Y, y ∈ L → 0 < g (x,y) := by sorry

theorem perturbed_block_gram_zero (r : ℕ) : perturbedBlockGram r 0 = enumeratedRealGram r := by sorry

theorem continuous_perturbed_block_gram (r : ℕ) : Continuous (perturbedBlockGram r) := by sorry

theorem continuous_normalized_orientation_product (r : ℕ) :
    Continuous (fun Z : FactorPair (Fintype.card (BlockIndex r)) (Fintype.card (BlockIndex r)) (3+r) ×
      Matrix (Fin (3+r)) (Fin (3+r)) ℝ => normalizedOrientationProduct (r := r) Z.1 Z.2) := by sorry

theorem actual_uniform_normalized_orientation_product_pos (r : ℕ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ η : ℝ, |η| < ε →
      ∀ F : FactorPair (Fintype.card (BlockIndex r)) (Fintype.card (BlockIndex r)) (3+r),
      F ∈ normalizedFactorSet (k := 3+r) (perturbedBlockGram r η) →
      ∀ O : Matrix (Fin (3+r)) (Fin (3+r)) ℝ, O ∈ orthogonalSet (3+r) →
        0 < normalizedOrientationProduct (r := r) F O := by sorry

theorem square_det_ne_zero_of_full_rank {n : ℕ} (M : Matrix (Fin n) (Fin n) ℝ)
    (hR : M.rank = n) : M.det ≠ 0 := by sorry

theorem actual_perturbed_block_full_rank_near_zero (r : ℕ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ η : ℝ, |η| < ε →
      (perturbedBlockGram r η).rank = (3+r)*(3+r+1)/2 := by sorry

theorem actual_regular_parameter_near_zero (r : ℕ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ η : ℝ, |η| < ε → regularParameter r η := by sorry

theorem actual_factor_row_sum_posDef {p q k : ℕ}
    (M : Matrix (Fin p) (Fin q) ℝ) (hR : M.rank = k*(k+1)/2)
    (F : NLA.PF02.Factorization M k) : (rowSum F.val.1).PosDef := by sorry

theorem actual_normalization_mem {p q k : ℕ}
    (M : Matrix (Fin p) (Fin q) ℝ) (hR : M.rank = k*(k+1)/2)
    (F : NLA.PF02.Factorization M k) :
    (normalizedRow F.val.1, normalizedColumn F.val.1 F.val.2) ∈ normalizedFactorSet (k := k) M := by sorry

theorem actual_normalized_orientation_ne_zero {r : ℕ} {η : ℝ} (h : regularParameter r η)
    (F : NLA.PF02.Factorization (perturbedBlockGram r η) (3+r)) :
    orientationPolynomial (leadingRows (r := r) (normalizedRow F.val.1)) ≠ 0 := by sorry

theorem actual_normalized_fiber_sign_congruent {r : ℕ} {η : ℝ} (h : regularParameter r η)
    (F G : NLA.PF02.Factorization (perturbedBlockGram r η) (3+r))
    (hFG : NLA.PF02.Congruent F G) : normalizedFiberSign F = normalizedFiberSign G := by sorry

theorem actual_factor_normalization_continuous {p q k : ℕ}
    (M : Matrix (Fin p) (Fin q) ℝ) (hR : M.rank = k*(k+1)/2) :
    Continuous (fun F : NLA.PF02.Factorization M k =>
      (normalizedRow F.val.1,normalizedColumn F.val.1 F.val.2)) := by sorry

theorem continuous_leading_orientation (r : ℕ) :
    Continuous (fun F : FactorPair (Fintype.card (BlockIndex r)) (Fintype.card (BlockIndex r)) (3+r) =>
      orientationPolynomial (leadingRows (r := r) F.1)) := by sorry

theorem actual_continuous_normalized_fiber_sign {r : ℕ} {η : ℝ} (h : regularParameter r η) :
    Continuous (normalizedFiberSign (r := r) (η := η)) := by sorry

theorem shifted_row_sum_posDef {p k : ℕ} (A : Fin p → Matrix (Fin k) (Fin k) ℝ)
    (hA : (rowSum A).PosDef) (η : ℝ) (hη : 0 ≤ η) :
    (rowSum (shiftedFactors A η)).PosDef := by sorry

theorem continuousOn_shifted_normalization {p k : ℕ}
    (A : Fin p → Matrix (Fin k) (Fin k) ℝ) (hA : (rowSum A).PosDef) :
    ContinuousOn (fun η : ℝ => normalizedRow (shiftedFactors A η)) (Ici 0) := by sorry

theorem actual_zero_normalization_orientation_product_pos {r : ℕ}
    (F : NLA.PF02.Factorization (enumeratedRealGram r) (3+r)) :
    0 < orientationPolynomial (leadingRows (r := r) F.val.1) *
      orientationPolynomial (leadingRows (r := r) (normalizedRow F.val.1)) := by sorry

theorem actual_zero_normalized_witness_product_negative (r : ℕ) :
    orientationPolynomial (leadingRows (r := r) (normalizedRow (enumeratedFactor r))) *
      orientationPolynomial (leadingRows (r := r) (normalizedRow (enumeratedReflectedFactor r))) < 0 := by sorry

theorem continuous_leading_rows (r : ℕ) :
    Continuous (leadingRows (r := r) :
      (Fin (Fintype.card (BlockIndex r)) → Matrix (Fin (3+r)) (Fin (3+r)) ℝ) →
      NLA.PF02.Paper.SymIndex 3 → Matrix (Fin (3+r)) (Fin (3+r)) ℝ) := by sorry

theorem continuousOn_normalized_witness_product (r : ℕ) :
    ContinuousOn (normalizedWitnessProduct r) (Ici 0) := by sorry

theorem actual_normalized_witness_product_negative_near_zero (r : ℕ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ η : ℝ, 0 ≤ η → η < ε → normalizedWitnessProduct r η < 0 := by sorry

theorem perturbed_gram_entry_expansion (r : ℕ) (η : ℝ)
    (i j : Fin (Fintype.card (BlockIndex r))) :
    perturbedBlockGram r η i j = enumeratedRealGram r i j +
      η * (enumeratedFactor r i).trace + η * (enumeratedFactor r j).trace + η^2 * (3+r) := by sorry

theorem actual_perturbed_gram_entries_positive (r : ℕ) (η : ℝ) (hη : 0 < η)
    (i j : Fin (Fintype.card (BlockIndex r))) : 0 < perturbedBlockGram r η i j := by sorry

theorem actual_perturbed_psd_rank {r : ℕ} {η : ℝ} (h : regularParameter r η) (hη : 0 ≤ η) :
    NLA.PF02.IsPSDRank (perturbedBlockGram r η) (3+r) := by sorry

theorem actual_perturbed_orbit_quotient_disconnected {r : ℕ} {η : ℝ}
    (h : regularParameter r η) (hη : 0 ≤ η) (hneg : normalizedWitnessProduct r η < 0) :
    ¬ IsConnected (Set.univ : Set (NLA.PF02.OrbitSpace (perturbedBlockGram r η) (3+r))) := by sorry

theorem actual_positive_perturbed_witness_near_zero (r : ℕ) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ η : ℝ, 0 < η → η < ε →
      (∀ i j, 0 < perturbedBlockGram r η i j) ∧
      (perturbedBlockGram r η).rank = (3+r)*(3+r+1)/2 ∧
      NLA.PF02.IsPSDRank (perturbedBlockGram r η) (3+r) ∧
      ¬ IsConnected (Set.univ : Set (NLA.PF02.OrbitSpace (perturbedBlockGram r η) (3+r))) := by sorry

theorem enumerated_integer_factor_cast (r : ℕ) (i : Fin (Fintype.card (BlockIndex r))) :
    (enumeratedIntegerFactor r i).map (Int.castRingHom ℝ) = enumeratedFactor r i := by sorry

theorem enumerated_integer_factor_trace_cast (r : ℕ) (i : Fin (Fintype.card (BlockIndex r))) :
    (((enumeratedIntegerFactor r i).trace : ℤ) : ℝ) = (enumeratedFactor r i).trace := by sorry

theorem rational_perturbed_gram_cast (r : ℕ) (q : ℚ) :
    (rationalPerturbedGram r q).map (Rat.castHom ℝ) = perturbedBlockGram r (q : ℝ) := by sorry

theorem all_size_positive_rational_disconnected_witness {k : ℕ} (hk : 3 ≤ k) :
    ∃ (N : ℕ) (M : Matrix (Fin N) (Fin N) ℚ), N = k*(k+1)/2 ∧
      (∀ i j, 0 < M i j) ∧ (M.map (Rat.castHom ℝ)).rank = N ∧
      NLA.PF02.IsPSDRank (M.map (Rat.castHom ℝ)) k ∧
      ¬ IsConnected (Set.univ : Set (NLA.PF02.OrbitSpace (M.map (Rat.castHom ℝ)) k)) := by sorry
end Reference.PF02UniformPositiveOrientation
