import NLA.MI22.PaperWitnessDefinitions

set_option autoImplicit false
noncomputable section
open scoped MatrixOrder ComplexOrder
namespace NLA.MI22.Paper

theorem paper_printed_inputs :
    witnessA = Matrix.diagonal (![256,1/256,1] : Fin 3 → ℂ) ∧
    paperB = !![17,-4,0; -4,16385,-8192; 0,-8192,4096] := by
  sorry

theorem paper_counterexample :
    witnessA.PosDef ∧ paperB.PosDef ∧
    10900 < operatorNorm (leftProduct witnessA paperB (1/8)) ∧
    operatorNorm (witnessA*paperB) < 10200 ∧
    ¬ SingularLogMajorized (leftProduct witnessA paperB (1/8)) (witnessA*paperB) := by
  sorry

theorem paper_conjecture_false :
    ¬ WeightedLogMajorizationConjecture := by
  sorry


end NLA.MI22.Paper
