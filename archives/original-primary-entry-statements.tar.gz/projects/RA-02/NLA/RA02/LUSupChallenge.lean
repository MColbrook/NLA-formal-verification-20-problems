import NLA.RA02.PaperLUSupDefinitions
import NLA.RA02.PaperCholeskySupDefinitions
import NLA.RA02.PaperBestErrorDefinitions

set_option autoImplicit false
noncomputable section
open scoped BigOperators Classical ComplexOrder Matrix
namespace NLA.RA02.Paper

theorem paper_sup_lu_expectedError_best_upper_positive {m n : ℕ}
    (A : Matrix (Fin m) (Fin n) ℂ) (r : ℕ)
    (ht : 0 < rectangularBestRankErrorSquared A r) :
    NLA.RA03.expectedError A r ≤ (4:ℝ)^r*rectangularBestRankErrorSquared A r := by
  sorry

theorem paper_sup_rectangular_best_error_attained {m n : ℕ}
    (A : Matrix (Fin m) (Fin n) ℂ) (r : ℕ) :
    ∃ B : Matrix (Fin m) (Fin n) ℂ, B.rank ≤ r ∧
      NLA.RA03.frobeniusSq (A-B) = gramTail A r := by
  sorry

theorem paper_sup_rectangularBest_eq_gramTail {m n : ℕ}
    (A : Matrix (Fin m) (Fin n) ℂ) (r : ℕ) :
    rectangularBestRankErrorSquared A r = gramTail A r := by
  sorry

theorem paper_sup_gramTail_le_lowRankError {m n : ℕ} (A B : Matrix (Fin m) (Fin n) ℂ)
    (r : ℕ) (hB : B.rank ≤ r) : gramTail A r ≤ NLA.RA03.frobeniusSq (A-B) := by
  sorry

theorem paper_sup_rectangularBest_eq_squareBest {n : ℕ} (A : NLA.RA02.Square n) (r : ℕ) :
    rectangularBestRankErrorSquared A r = bestRankErrorSquared A r := by
  sorry

theorem paper_sup_luRatios_isLUB (r : ℕ) : IsLUB (luRatios r) ((4:ℝ)^r) := by
  sorry

theorem paper_sup_realPositiveLURatios_isLUB (r : ℕ) : IsLUB (realPositiveLURatios r) ((4:ℝ)^r) := by
  sorry

theorem paper_sup_best_error_semantics {m n : ℕ} (A : Matrix (Fin m) (Fin n) ℂ) (r : ℕ) :
    rectangularBestRankErrorSquared A r = sInf {e : ℝ | ∃ B : Matrix (Fin m) (Fin n) ℂ, B.rank ≤ r ∧ NLA.RA03.frobeniusSq (A-B) = e} := by
  sorry

theorem paper_sup_lu_ratios_semantics (r : ℕ) (x : ℝ) :
    x ∈ luRatios r ↔ ∃ (m n : ℕ) (A : Matrix (Fin m) (Fin n) ℂ), 0 < rectangularBestRankErrorSquared A r ∧ x = NLA.RA03.expectedError A r / rectangularBestRankErrorSquared A r := by
  sorry

theorem paper_sup_real_positive_lu_ratios_semantics (r : ℕ) (x : ℝ) :
    x ∈ realPositiveLURatios r ↔ ∃ (n : ℕ) (A : NLA.RA02.Square n) (hA : A.PosDef), (∀ i j, (A i j).im = 0 ∧ 0 < (A i j).re) ∧ 0 < rectangularBestRankErrorSquared A r ∧ x = NLA.RA03.expectedError A r / rectangularBestRankErrorSquared A r := by
  sorry

theorem paper_sup_worst_case_constants (r : ℕ) :
    IsLUB (choleskyRatios r) ((2:ℝ)^r) ∧ IsLUB (realPositiveCholeskyRatios r) ((2:ℝ)^r) ∧ IsLUB (luRatios r) ((4:ℝ)^r) ∧ IsLUB (realPositiveLURatios r) ((4:ℝ)^r) := by
  sorry

end NLA.RA02.Paper
