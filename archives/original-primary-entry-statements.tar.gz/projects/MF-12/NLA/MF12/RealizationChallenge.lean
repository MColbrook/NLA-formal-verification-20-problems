import NLA.MF12.PaperRealizationDefinitions

set_option autoImplicit false
noncomputable section
namespace NLA.MF12.Paper

theorem paper_main_realization (γ : ℝ) (hγ : 0 ≤ γ) :
    ∃ d : ℕ, d = paperDimension γ ∧ 1 ≤ d ∧
      ∃ A P : Square d, Realizes A P γ ∧
        ((∃ q : ℚ, (q : ℝ) = γ) → ∀ i j, IsDyadic (A i j) ∧ IsDyadic (P i j)) := by
  sorry

theorem paper_dimension_integer (m : ℕ) : paperDimension (m : ℝ) = m+1 := by
  sorry

theorem paper_dimension_fractional (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    paperDimension γ = 6 := by
  sorry

theorem paper_dimension_noninteger (γ : ℝ) (hγ : ¬ ∃ m : ℕ, γ = (m : ℝ)) :
    paperDimension γ = 6*(⌊γ⌋₊+1) := by
  sorry

theorem paper_rational_realization (q : ℚ) (hq : 0 ≤ q) :
    ∃ d : ℕ, d = paperDimension (q : ℝ) ∧ 1 ≤ d ∧
      ∃ A P : Square d, Realizes A P (q : ℝ) ∧
        ∀ i j, IsDyadic (A i j) ∧ IsDyadic (P i j) := by
  sorry

theorem paper_two_generators {d : ℕ} (A P : Square d) (γ : ℝ)
    (h : Realizes A P γ) : (pairFamily A P).card = 2 := by
  sorry


end NLA.MF12.Paper
