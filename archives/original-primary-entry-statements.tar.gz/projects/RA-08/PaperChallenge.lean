import NLA.RA08.PaperDefinitions

set_option autoImplicit false
noncomputable section
open scoped MatrixOrder
open Matrix
namespace NLA.RA08.Paper

theorem paper_spectral_witness :
    Nonempty (OrderedSpectralData witnessMatrix) ∧
    Function.Injective (fun x => paperOmega *ᵥ x) ∧
    IsUnit (paperOmega.transpose * witnessMatrix * paperOmega).det ∧
    witnessMatrix.PosDef ∧ witnessApproximation.PosSemidef ∧
    witnessApproximation ≤ witnessMatrix ∧
    nystrom witnessMatrix paperOmega = witnessApproximation := by
  sorry

theorem paper_spectral_errors (dA : OrderedSpectralData witnessMatrix) :
    spectralNorm (witnessMatrix - witnessApproximation) = witnessT ∧
    spectralNorm (witnessMatrix - truncation dA 3) = witnessT ∧
    spectralNorm (functionalCalculus witnessFunction witnessMatrix -
      functionTruncation dA witnessFunction 3) = witnessT ∧
    1 + (334583 / 15769728 : ℝ) ≤
      spectralNorm (functionalCalculus witnessFunction witnessMatrix -
        functionalCalculus witnessFunction witnessApproximation) /
      spectralNorm (functionalCalculus witnessFunction witnessMatrix -
        functionTruncation dA witnessFunction 3) ∧
    (1 : ℝ) < 1 + (334583 / 15769728 : ℝ) := by
  sorry

theorem paper_spectral_failure (C : ℝ) (dA : OrderedSpectralData witnessMatrix) :
    spectralNorm (witnessMatrix - witnessApproximation) ≤
      (1 + (0 : ℝ)) * spectralNorm (witnessMatrix - truncation dA 3) ∧
    ¬ (spectralNorm (functionalCalculus witnessFunction witnessMatrix -
          functionalCalculus witnessFunction witnessApproximation) ≤
        (1 + C * 0) * spectralNorm (functionalCalculus witnessFunction witnessMatrix -
          functionTruncation dA witnessFunction 3)) := by
  sorry

theorem paper_scalar_function :
    AdmissibleFunction witnessFunction ∧ witnessFunction 0 = 0 := by
  sorry


end NLA.RA08.Paper
