import NLA.RA08.PaperNuclearCounterexampleDefinitions

set_option autoImplicit false
noncomputable section
open scoped Classical Matrix BigOperators
namespace NLA.RA08.Paper

theorem verified_nuclear_spectralCombination_nonnegative {n : ℕ} {A : RealMatrix n}
    (d : OrderedSpectralData A) (v : Fin n → ℝ) (hv : ∀ i, 0 ≤ v i) :
    nuclearNorm (spectralCombination d v)=∑ i, v i := by
  sorry

theorem verified_nuclear_truncation_last {n : ℕ} {A : RealMatrix (n+1)}
    (d : OrderedSpectralData A) :
    nuclearNorm (A-truncation d n)=d.eigenvalues (Fin.last n) := by
  sorry

theorem verified_nuclear_functionTruncation_last {n : ℕ} {A : RealMatrix (n+1)}
    (d : OrderedSpectralData A) (f : ℝ → ℝ)
    (hf : ∀ i, 0 ≤ f (d.eigenvalues i)) :
    nuclearNorm (functionalCalculus f A-functionTruncation d f n)=
      f (d.eigenvalues (Fin.last n)) := by
  sorry

theorem verified_nuclearLiftSmallest_eq_last (m : ℕ) (η t : ℝ)
    (d : OrderedSpectralData (nuclearLiftA m η t)) :
    nuclearLiftSmallest m η t=d.eigenvalues (Fin.last (m+m)) := by
  sorry

theorem verified_nuclearLift_ordered_exists (m : ℕ) (η t : ℝ) (hη : η < 1) (ht : 0 < t) :
    Nonempty (OrderedSpectralData (nuclearLiftA m η t)) := by
  sorry

theorem verified_nuclearLift_truncation_tail (m : ℕ) (η t : ℝ)
    (d : OrderedSpectralData (nuclearLiftA m η t)) :
    nuclearNorm (nuclearLiftA m η t-truncation d (m+m))=nuclearLiftSmallest m η t := by
  sorry

theorem verified_nuclearLift_clipping_tail (m : ℕ) (η t : ℝ)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) (ht0 : 0 ≤ t) (ht1 : t ≤ 1/4)
    (d : OrderedSpectralData (nuclearLiftA m η t)) :
    nuclearNorm (functionalCalculus witnessFunction (nuclearLiftA m η t)-
      functionTruncation d witnessFunction (m+m))=nuclearLiftSmallest m η t := by
  sorry

theorem verified_frobeniusNorm_spectral_bound (n : ℕ) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ A : RealMatrix n, frobeniusNorm A ≤ K*spectralNorm A := by
  sorry

theorem verified_nuclearNorm_spectral_bound (n : ℕ) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ A : RealMatrix n, nuclearNorm A ≤ K*spectralNorm A := by
  sorry

theorem verified_clipping_nuclear_quadratic_remainder {n : ℕ} (b : Fin n → ℝ)
    (hb : ∀ i, b i ≠ 1) (E : RealMatrix n) (hE : E.IsHermitian) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ t : ℝ,
      nuclearNorm (functionalCalculus witnessFunction (Matrix.diagonal b+t • E)-
        functionalCalculus witnessFunction (Matrix.diagonal b)-t • clippingDerivative b E) ≤ C*t^2 := by
  sorry

theorem verified_clippingDividedDifference_symmetric (x y : ℝ) :
    clippingDividedDifference x y=clippingDividedDifference y x := by
  sorry

theorem verified_clippingDerivative_isHermitian {n : ℕ} (b : Fin n → ℝ)
    (E : RealMatrix n) (hE : E.IsHermitian) : (clippingDerivative b E).IsHermitian := by
  sorry

theorem verified_nuclearLiftDerivative_prefix (m : ℕ) (η : ℝ) (hη : 0 ≤ η)
    (i j : Fin (m+m)) :
    nuclearLiftDerivative m η i.castSucc j.castSucc=η*nuclearDerivative m i j := by
  sorry

theorem verified_nuclearLiftDerivative_last (m : ℕ) (η : ℝ) (hη : η ≤ 1) :
    nuclearLiftDerivative m η (Fin.last (m+m)) (Fin.last (m+m))=1-η := by
  sorry

theorem verified_nuclearLiftDerivative_isHermitian (m : ℕ) (η : ℝ) :
    (nuclearLiftDerivative m η).IsHermitian := by
  sorry

theorem verified_nuclearLiftOutput_isHermitian (m : ℕ) (η t : ℝ) :
    (nuclearLiftOutput m η t).IsHermitian := by
  sorry

theorem verified_nuclearLift_nuclear_remainder (m : ℕ) (η : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ t : ℝ,
      nuclearNorm (nuclearLiftOutput m η t-t • nuclearLiftDerivative m η) ≤ C*t^2 := by
  sorry

theorem verified_nuclearLiftUnitary_unitary {n : ℕ} (R : RealMatrix n)
    (hR : R ∈ Matrix.unitaryGroup (Fin n) ℝ) :
    nuclearLiftUnitary R ∈ Matrix.unitaryGroup (Fin (n+1)) ℝ := by
  sorry

theorem verified_nuclearLiftUnitary_trace {n : ℕ} (R : RealMatrix n) (G : RealMatrix (n+1)) :
    (nuclearLiftUnitary R*G).trace=
      (R*G.submatrix Fin.castSucc Fin.castSucc).trace+G (Fin.last n) (Fin.last n) := by
  sorry

theorem verified_nuclearLiftDerivative_trace (m : ℕ) (η : ℝ) (hη0 : 0 ≤ η) (hη1 : η ≤ 1) :
    (nuclearLiftUnitary (functionalCalculus realSign (nuclearDerivative m))*
      nuclearLiftDerivative m η).trace=η*nuclearNorm (nuclearDerivative m)+1-η := by
  sorry

theorem verified_nuclearLiftDerivative_nuclear_lower (m : ℕ) (η : ℝ)
    (hη0 : 0 ≤ η) (hη1 : η ≤ 1) :
    η*nuclearNorm (nuclearDerivative m)+1-η ≤ nuclearNorm (nuclearLiftDerivative m η) := by
  sorry

theorem verified_nuclearLiftOutput_lower (m : ℕ) (η : ℝ) (hη0 : 0 ≤ η) (hη1 : η ≤ 1) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ t : ℝ, 0 ≤ t →
      t*(η*nuclearNorm (nuclearDerivative m)+1-η)-K*t^2 ≤
        nuclearNorm (nuclearLiftOutput m η t) := by
  sorry

theorem verified_nuclear_choose_eta (ε₀ : ℝ) (hε : 0 < ε₀) :
    ∃ η : ℝ, 0 < η ∧ η < 1 ∧ 1 < (1-η)*(1+ε₀) := by
  sorry

theorem verified_nuclear_small_time (η D K C ε₀ : ℝ)
    (hη0 : 0 < η) (hη1 : η < 1) (hK : 0 ≤ K) (hC : 0 ≤ C)
    (hε : 0 < ε₀) (hgap : 1 < (1-η)*(1+ε₀)) (hD : C < D) :
    ∃ t : ℝ, 0 < t ∧ t ≤ 1/4 ∧ ∀ a : ℝ, 0 < a →
      nuclearLiftTailLower η t ≤ a → a ≤ (1-η)*t →
      0 < t/a-1 ∧ t/a-1 < ε₀ ∧ t=(1+(t/a-1))*a ∧
      (1+C*(t/a-1))*a < t*(η*D+1-η)-K*t^2 := by
  sorry

theorem verified_paper_nuclear_counterexample (C ε₀ : ℝ) (hC : 0 ≤ C) (hε : 0 < ε₀) :
    NuclearTransferFailure C ε₀ := by
  sorry

end NLA.RA08.Paper
