import NLA.IV04.FullHullHardnessDefinitions
set_option autoImplicit false
namespace Reference.IV04FullHullHardness
open Complexity IV04.Paper.Computational
open IV04.Paper.Computational.SATReduction

theorem project_full_hull_packet_mem_fp : projectFullHullPacket ∈ FP := by
  sorry

theorem sat_full_hull_finish_mem_fp : satFullHullFinish ∈ FP := by
  sorry

theorem sat_full_hull_output_exists (input : List Bool) :
    ∃ answer, ExactFullHullOutput (polynomialSATOutputQuery input) answer := by
  sorry

theorem sat_full_hull_finish_correct (input answer : List Bool)
    (h : ExactFullHullOutput (polynomialSATOutputQuery input) answer) :
    firstBit (satFullHullFinish (pair input answer)) = true ↔ input ∈ SAT.language := by
  sorry

theorem sat_full_hull_one_query_reduction :
    PolynomialOneQueryReduction SAT.language ExactFullHullOutput := by
  sorry

theorem iv_hull_literal_np_hard : NPHardOutputTask ExactFullHullOutput := by
  sorry

end Reference.IV04FullHullHardness
