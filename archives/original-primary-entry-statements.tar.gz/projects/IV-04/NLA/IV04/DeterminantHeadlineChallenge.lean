import NLA.IV04.PaperDeterminantHeadlineDefinitions
set_option autoImplicit false
namespace IV04.Paper.Computational
open Complexity SATReduction

theorem actual_sat_matrix_packet_regular :
  ∀ input : List Bool, RegularUnitMatrixPacket (polynomialSATMatrixCode input) := by sorry

theorem actual_sat_output_query_packet_regular :
  ∀ input : List Bool, RegularUnitMatrixPacket (polynomialSATOutputQuery input) := by sorry

theorem actual_binary_sat_regular_determinant_reduction :
  ∀ input : List Bool, input ∈ SAT.language ↔ polynomialSATMatrixCode input ∈ regularUnitMatrixDeterminantDecisionLanguage := by sorry

theorem actual_binary_sat_regular_determinant_map_reduction :
  SAT.language ≤ₚ regularUnitMatrixDeterminantDecisionLanguage := by sorry

theorem actual_regular_unit_determinant_np_hard :
  NPHard regularUnitMatrixDeterminantDecisionLanguage := by sorry

theorem regular_unit_exact_determinant_range_output_np_hard :
  NPHardOutputTask RegularUnitDeterminantRangeOutput := by sorry

theorem actual_paper_iv_det :
  NPComplete rationalMatrixDeterminantDecisionLanguage ∧
  NPHard regularUnitMatrixDeterminantDecisionLanguage ∧
  NPHardOutputTask RegularUnitDeterminantRangeOutput := by sorry
end IV04.Paper.Computational
