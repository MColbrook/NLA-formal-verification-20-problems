import NLA.MD06.MainAssembly.RadiusDefinitions
import NLA.MD06.MainAssembly.EventDefinitions
import NLA.MD06.CleanRadiusProbability.PureDefinitions
import NLA.MD06.GraphCycleWalk.Definitions
import NLA.MD06.FiniteProbability.Nonempty
import NLA.MD06.CycleProfile.RootDefinitions
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import LeanCert.Tactic.Verification

set_option autoImplicit false
noncomputable section
namespace Reference.MD06MainAssembly.Interface
open Reference.MD06MainAssembly Reference.MD06Actual Reference.MD06Spectral Reference.MD06RadiusEmbedding
open Reference.MD06FiniteProbability Reference.MD06GraphCycleWalk Reference.MD06CleanRadiusProbability
open Reference.MD06CycleProfile
open Filter Topology
open scoped BigOperators
attribute [local instance] Classical.propDecidable

theorem actual_paper_radius_at_least_four (ell : ℕ) : 4≤PaperRadius ell := by sorry

theorem actual_paper_radius_inequality (ell : ℕ) (hell : 0<ell) :
    32*(ell : ℝ)/((Real.sqrt (1-(Root 4)^2))^4*(1/10 : ℝ)^2)<
      (2 : ℝ)^(PaperRadius ell-1) := by sorry

theorem actual_literal_stable_event_from_gap_clean_cycle {n : ℕ}
    (G : SimpleGraph (Fin n)) (hcubic : G.IsRegularOfDegree 3)
    (ell : ℕ) (hell : 4≤ell) (hdiv : 4∣ell)
    (hgap : (1/10 : ℝ)≤TotalLaplacianGap G)
    (hclean : ¬BadCycleRadius G ell (PaperRadius ell))
    (hcycle : WalkCycleExists G ell) : StableNonsynchronized G := by sorry

theorem actual_literal_stable_event_not_all_minima_synchronized {n : ℕ}
    (G : SimpleGraph (Fin n)) (h : StableNonsynchronized G) :
    ¬EveryLocalMinimumSynchronized G := by sorry

theorem actual_literal_stable_failure_union_bound (k ell : ℕ) (hell : 4≤ell) (hdiv : 4∣ell) :
    GraphProbability k (fun G=>¬StableNonsynchronized G)≤
      GraphProbability k (fun G=>¬((1/10 : ℝ)≤TotalLaplacianGap G))+
      GraphProbability k (fun G=>BadCycleRadius G ell (PaperRadius ell))+
      GraphProbability k (fun G=>¬WalkCycleExists G ell) := by sorry

theorem actual_fourfold_cycle_mean_lower (q : ℕ) :
    (q : ℝ)+1≤(2 : ℝ)^(4*(q+1))/(2*(4*(q+1) : ℕ)) := by sorry

theorem actual_fourfold_no_cycle_target_tendsto_zero :
    Tendsto (fun q : ℕ=>Real.exp (-((2 : ℝ)^(4*(q+1))/(2*(4*(q+1) : ℕ)))))
      atTop (𝓝 0) := by sorry

theorem actual_uniform_total_gap_failure_tendsto_zero :
    Tendsto (fun k=>GraphProbability k (fun G=>¬((1/10 : ℝ)≤TotalLaplacianGap G))) atTop (𝓝 0) := by sorry

theorem actual_uniform_literal_stable_failure_tendsto_zero :
    Tendsto (fun k=>GraphProbability k (fun G=>¬StableNonsynchronized G)) atTop (𝓝 0) := by sorry

theorem actual_uniform_literal_stable_probability_tendsto_one :
    Tendsto (fun k=>GraphProbability k StableNonsynchronized) atTop (𝓝 1) := by sorry

theorem actual_uniform_all_local_minima_synchronized_tendsto_zero :
    Tendsto (fun k=>GraphProbability k EveryLocalMinimumSynchronized) atTop (𝓝 0) := by sorry

theorem actual_uniform_cubic_literal_stable_mass_tendsto_one :
    Tendsto (fun k=>((UniformCubic k).toOuterMeasure {G : CubicSample k|StableNonsynchronized G.val}).toReal)
      atTop (𝓝 1) := by sorry

theorem actual_uniform_cubic_all_local_minima_synchronized_mass_tendsto_zero :
    Tendsto (fun k=>((UniformCubic k).toOuterMeasure {G : CubicSample k|EveryLocalMinimumSynchronized G.val}).toReal)
      atTop (𝓝 0) := by sorry

theorem actual_paper_md_main :
    (Tendsto (fun k=>((UniformCubic k).toOuterMeasure {G : CubicSample k|
      ∀ theta : Phase (Size k),IsLocalMin (Energy G.val) theta → Synchronized theta}).toReal)
      atTop (𝓝 0)) ∧
    Tendsto (fun k=>((UniformCubic k).toOuterMeasure {G : CubicSample k|
      ∃ theta : Phase (Size k), (∀ i,Gradient G.val theta i=0) ∧
        IsLocalMin (Energy G.val) theta ∧ ¬Synchronized theta ∧
        (∀ i j,G.val.Adj i j → (1/32 : ℝ)<Real.Angle.cos (theta i-theta j)) ∧
        ∀ z : Fin (Size k)→ℝ,(∑ i,z i)=0 →
          (1/320 : ℝ)*(∑ i,(z i)^2)≤HessianQuadratic G.val theta z}).toReal)
      atTop (𝓝 1) := by sorry
end Reference.MD06MainAssembly.Interface
