import Mathlib.Combinatorics.SimpleGraph.Acyclic
import Mathlib.Combinatorics.SimpleGraph.DeleteEdges
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import NLA.MD06.CleanCycleGraph.ResidualDefinitions

universe u_1
namespace Reference.MD06RadiusEmbedding
open SimpleGraph
attribute [local instance] Classical.propDecidable
variable {V : Type u_1} {G : SimpleGraph V}

def UniqueCycleEdges {v : V} (c : G.Walk v v) : Prop :=
  c.IsCycle ∧ ∀ ⦃u : V⦄ (p : G.Walk u u), p.IsCycle →
    ∀ e : Sym2 V, e ∈ p.edges ↔ e ∈ c.edges

def CycleRadius {v : V} (G : SimpleGraph V) (c : G.Walk v v) (R : ℕ) : Set V :=
  {x | ∃ u ∈ c.support, G.Reachable x u ∧ G.dist x u ≤ R}

theorem actual_cycle_member_radius :
∀ {V : Type u_1} {G : SimpleGraph.{u_1} V} {v x : V} (c : @SimpleGraph.Walk.{u_1} V G v v) (R : Nat)
  (hx :
    @Membership.mem.{u_1, u_1} V (List.{u_1} V) (@List.instMembership.{u_1} V)
      (@SimpleGraph.Walk.support.{u_1} V G v v c) x),
  @Membership.mem.{u_1, u_1} V (Set.{u_1} V) (@Set.instMembership.{u_1} V)
    (@Reference.MD06RadiusEmbedding.CycleRadius.{u_1} V v G c R) x :=
fun {V : Type u_1} {G : SimpleGraph.{u_1} V} {v x : V} (c : @SimpleGraph.Walk.{u_1} V G v v) (R : Nat)
    (hx :
      @Membership.mem.{u_1, u_1} V (List.{u_1} V) (@List.instMembership.{u_1} V)
        (@SimpleGraph.Walk.support.{u_1} V G v v c) x) =>
  @Exists.intro.{u_1 + 1} V
    (fun (u : V) =>
      And
        (@Membership.mem.{u_1, u_1} V (List.{u_1} V) (@List.instMembership.{u_1} V)
          (@SimpleGraph.Walk.support.{u_1} V G v v c) u)
        (And (@SimpleGraph.Reachable.{u_1} V G x u) (@LE.le.{0} Nat instLENat (@SimpleGraph.dist.{u_1} V G x u) R)))
    x
    (@And.intro
      (@Membership.mem.{u_1, u_1} V (List.{u_1} V) (@List.instMembership.{u_1} V)
        (@SimpleGraph.Walk.support.{u_1} V G v v c) x)
      (And (@SimpleGraph.Reachable.{u_1} V G x x) (@LE.le.{0} Nat instLENat (@SimpleGraph.dist.{u_1} V G x x) R)) hx
      (@And.intro (@SimpleGraph.Reachable.{u_1} V G x x) (@LE.le.{0} Nat instLENat (@SimpleGraph.dist.{u_1} V G x x) R)
        (@SimpleGraph.Reachable.refl.{u_1} V G x)
        (@Eq.mpr.{0} (@LE.le.{0} Nat instLENat (@SimpleGraph.dist.{u_1} V G x x) R)
          (@LE.le.{0} Nat instLENat (@OfNat.ofNat.{0} Nat (nat_lit 0) (instOfNatNat (nat_lit 0))) R)
          (@id.{0}
            (@Eq.{1} Prop (@LE.le.{0} Nat instLENat (@SimpleGraph.dist.{u_1} V G x x) R)
              (@LE.le.{0} Nat instLENat (@OfNat.ofNat.{0} Nat (nat_lit 0) (instOfNatNat (nat_lit 0))) R))
            (@congrFun'.{1, 1} Nat Prop (@LE.le.{0} Nat instLENat (@SimpleGraph.dist.{u_1} V G x x))
              (@LE.le.{0} Nat instLENat (@OfNat.ofNat.{0} Nat (nat_lit 0) (instOfNatNat (nat_lit 0))))
              (@congrArg.{1, 1} Nat (Nat → Prop) (@SimpleGraph.dist.{u_1} V G x x)
                (@OfNat.ofNat.{0} Nat (nat_lit 0) (instOfNatNat (nat_lit 0))) (@LE.le.{0} Nat instLENat)
                (@SimpleGraph.dist_self.{u_1} V G x))
              R))
          (Nat.zero_le R))))

noncomputable def LiftedCycle {v : V} (c : G.Walk v v) (R : ℕ) :=
  c.induce (CycleRadius G c R) (fun _x hx => actual_cycle_member_radius c R hx)





variable [Fintype V]

noncomputable def ForwardChildren (G : SimpleGraph V) (root v : V) : Finset V :=
  (G.neighborFinset v).filter (fun w => G.dist root w = G.dist root v + 1)

noncomputable def DistanceLayer (G : SimpleGraph V) (root : V) (j : ℕ) : Finset V :=
  @Finset.filter V (fun x => G.Reachable root x ∧ G.dist root x = j)
    (fun x => @instDecidableAnd (G.Reachable root x) (G.dist root x = j)
      (Classical.propDecidable _) (instDecidableEqNat (G.dist root x) j))
    Finset.univ

variable [DecidableEq V]





end Reference.MD06RadiusEmbedding
