import NLA.MD06.RadiusInterfaceR2.PureBaseDefinitions

namespace Reference.MD06RadiusEmbedding
open SimpleGraph
attribute [local instance] Classical.propDecidable
variable {V : Type*} {G : SimpleGraph V}

noncomputable abbrev RadiusForest {v : V} (G : SimpleGraph V) (c : G.Walk v v) (R : ℕ) :=
  (G.induce (CycleRadius G c R)).deleteEdges {e | e ∈ (LiftedCycle c R).edges}

variable [Fintype V] [DecidableEq V]

noncomputable def RadiusRootLayer {v : V} (G : SimpleGraph V) (c : G.Walk v v)
    (R j : ℕ) : Finset (CycleRadius G c R) :=
  (LiftedCycle c R).support.toFinset.biUnion (fun r => DistanceLayer (RadiusForest G c R) r j)

end Reference.MD06RadiusEmbedding
