import NLA.MD06.RadiusInterfaceR2.PureForestDefinitions

namespace Reference.MD06RadiusEmbedding
open SimpleGraph
attribute [local instance] Classical.propDecidable
variable {V : Type*} {G : SimpleGraph V}

def CleanRadius {v : V} (G : SimpleGraph V) (c : G.Walk v v) (R : ℕ) : Prop :=
  UniqueCycleEdges (LiftedCycle c R)

end Reference.MD06RadiusEmbedding
