import NLA.IV04.ConcreteOracleSearchDefinitions
import NLA.IV04.InequalityFeasibilityBridges
set_option autoImplicit false
set_option leancert.trust "kernel"
namespace Reference.IV04ConcreteOracleSearchProof
theorem verifier_frozen (input : List Bool) :
    Reference.IV04ConcreteOracleSearch.polynomialInequalitySystemVerifier input=
      IV04.Paper.Computational.polynomialInequalitySystemVerifier input := by
  exact congrFun IV04.Paper.InequalityVerifier.polynomialInequalitySystemVerifier_frozen input
theorem accepted_certificate_frozen (instanceCode certificate : List Bool) :
    Reference.IV04ConcreteOracleSearch.acceptedCertificate instanceCode certificate ↔
      IV04.Paper.Computational.polynomialInequalitySystemVerifier (Complexity.pair instanceCode certificate)=[true] := by
  unfold Reference.IV04ConcreteOracleSearch.acceptedCertificate
  rw [verifier_frozen]
theorem instance_code_frozen {m n : ℕ} (A : Matrix (Fin m) (Fin n) ℤ) (b : Fin m → ℤ) :
    Reference.IV04ConcreteOracleSearch.integerMatrixInstanceCode A b=
      IV04.Paper.InequalityCertificate.integerMatrixInstanceCode A b := by rfl
theorem instance_polynomial_frozen : Reference.IV04ConcreteOracleSearch.inequalityInstanceLengthPolynomial=
    IV04.Paper.InequalityCertificate.inequalityInstanceLengthPolynomial := by rfl
theorem realMatrix_frozen {ι κ : Type*} (M : Matrix ι κ ℚ) :
    Reference.IV04ConcreteOracleSearch.realMatrix M=Reference.IV04AffinePolyhedronSteps.realMatrix M := by rfl
theorem realVector_frozen {ι : Type*} (b : ι → ℚ) :
    Reference.IV04ConcreteOracleSearch.realVector b=Reference.IV04AffinePolyhedronSteps.realVector b := by rfl
theorem integerRealMatrix_frozen {ι κ : Type*} (M : Matrix ι κ ℤ) :
    Reference.IV04ConcreteOracleSearch.integerRealMatrix M=Reference.IV04AffinePolyhedronSteps.integerRealMatrix M := by rfl
theorem integerRealVector_frozen {ι : Type*} (b : ι → ℤ) :
    Reference.IV04ConcreteOracleSearch.integerRealVector b=Reference.IV04AffinePolyhedronSteps.integerRealVector b := by rfl
#print axioms verifier_frozen
#assert_trust kernel verifier_frozen
#print axioms accepted_certificate_frozen
#assert_trust kernel accepted_certificate_frozen
#print axioms instance_code_frozen
#assert_trust kernel instance_code_frozen
#print axioms instance_polynomial_frozen
#assert_trust kernel instance_polynomial_frozen
#print axioms realMatrix_frozen
#assert_trust kernel realMatrix_frozen
#print axioms realVector_frozen
#assert_trust kernel realVector_frozen
#print axioms integerRealMatrix_frozen
#assert_trust kernel integerRealMatrix_frozen
#print axioms integerRealVector_frozen
#assert_trust kernel integerRealVector_frozen
end Reference.IV04ConcreteOracleSearchProof
