/- Finite actual original-row Gram candidates; no threshold facet is added. -/
import NLA.IV04.OriginalObjectiveAttainment.Domination
import NLA.IV04.AffinePolyhedronSteps.RationalVertex

set_option autoImplicit false
set_option leancert.trust "kernel"
namespace Reference.IV04OriginalObjectiveAttainment
noncomputable section
open scoped Matrix
open Reference.IV04AffinePolyhedronSteps

def maskedMatrix {ι : Type*} [DecidableEq ι] {n : ℕ}
    (A : Matrix ι (Fin n) ℚ) (I : Finset ι) : Matrix ι (Fin n) ℚ :=
  fun i j => if i ∈ I then A i j else 0
def maskedBounds {ι : Type*} [DecidableEq ι] (b : ι → ℚ) (I : Finset ι) : ι → ℚ :=
  fun i => if i ∈ I then b i else 0
def originalMaskCandidate {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (A : Matrix ι (Fin n) ℚ) (b : ι → ℚ) (I : Finset ι) : Fin n → ℚ :=
  cramerCandidate ((maskedMatrix A I)ᵀ*maskedMatrix A I)
    ((maskedMatrix A I)ᵀ *ᵥ maskedBounds b I)
def feasibleCandidateMasks {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (A : Matrix ι (Fin n) ℚ) (b : ι → ℚ) : Finset (Finset ι) := by
  classical
  exact Finset.univ.filter (fun I => feasible (realMatrix A) (realVector b)
    (realVector (originalMaskCandidate A b I)))

theorem original_tight_kernel_point_is_mask_candidate
    {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (A : Matrix ι (Fin n) ℚ) (b : ι → ℚ) (x : Fin n → ℝ)
    (hkernel : ∀ d : Fin n → ℝ,
      (∀ i ∈ tightRows (realMatrix A) (realVector b) x, (realMatrix A *ᵥ d) i=0) → d=0) :
    realVector (originalMaskCandidate A b (tightRows (realMatrix A) (realVector b) x))=x := by
  exact (rational_tight_cramer_recovery A b x hkernel).2

theorem mem_feasibleCandidateMasks_iff
    {ι : Type*} [Fintype ι] [DecidableEq ι] {n : ℕ}
    (A : Matrix ι (Fin n) ℚ) (b : ι → ℚ) (I : Finset ι) :
    I ∈ feasibleCandidateMasks A b ↔ feasible (realMatrix A) (realVector b)
      (realVector (originalMaskCandidate A b I)) := by
  classical
  simp [feasibleCandidateMasks]

#print axioms original_tight_kernel_point_is_mask_candidate
#assert_trust kernel original_tight_kernel_point_is_mask_candidate
#print axioms mem_feasibleCandidateMasks_iff
#assert_trust kernel mem_feasibleCandidateMasks_iff
end
end Reference.IV04OriginalObjectiveAttainment
